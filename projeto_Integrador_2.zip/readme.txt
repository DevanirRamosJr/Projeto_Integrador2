Guia de usuário:

!Atenção esse software ainda está em desenvolvimento


Tela Inicial:
    Clique no botão "Água" ou aperte ctrl + a para iniciar a tela de digitação de contas de água.

    Clique no botão "Luz" ou aperte ctrl + s para iniciar a tela de digitação de contas de luz.

    Botão relatório ainda em desenvolvimento


Tela Água:

    Os campos RGI, Cliente, No da Conta, Mes de Referencia, Consumo m3, Total a Pagar e Vencimento aceitam qualquer tipo de dado pois o projeto ainda está em desenvolvimento.

    Para salvar no banco de dados da memória principal clique em "Salvar" ou aperte ctrl + s.

    Para procurar por uma conta já cadastrada digite o RGI e clique em "Procurar" ou aperte ctrl + d.

    Para limpar os campos de digitação clique em "Limpar" ou aperte ctrl + f.


Tela Luz:

    Os campos Instalação, Cliente, Vencimento e Conta do Mês aceitam qualquer tipo de dados pois ainda estão em desenvolimento.

    Os campos Consumo KWH, Tarifa, PIS, COFINS, ICMS e Total a Pagar aceitam somente números. Atenção, utilizar ponto final (".") ao ínvés da vírgula (",") para digitar números com casas decimais.

    Para salvar no banco de dados da memória principal clique em "Salvar" ou aperte ctrl + s, nesse momento o programa fará um cálculo para checar se o Total a Pagar está correto, caso não esteja uma caixa de diálogo é apresentada para o digitador. Atenção, mesmo se o total estiver errado a conta é cadastrada podendo ser editada com o botão "Procurar".

    Para procurar por uma conta já cadastrada digite a instalação e clique em "Procurar" ou aperte ctrl + d.

    Para limpar os campos de digitação clique em "Limpar" ou aperte ctrl + f.


Como editar uma conta já cadastrada:
    
    Em caso de erro de digitação ou contas com dados errados, basta procurar pelo cadastro com o botão "Procurar", corrigir o(s) campo(s) errados e clicar em "Salvar". Atenção, o RGI e instalação não podem ser alterados pois são identificadores de contas, caso erre a digitação desses dados, poderá ser usado o botão "Histórico" que está em desenvolvimento.
